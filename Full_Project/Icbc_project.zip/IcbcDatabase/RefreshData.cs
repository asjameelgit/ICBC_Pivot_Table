﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IcbcDatabase.Model;

namespace IcbcDatabase
{
    public static class RefreshData
    {
        public static void Refresh()
        {
            icbcEntities dbEntities = new icbcEntities();
            string cmd = $"DELETE FROM RAWDATA";
            dbEntities.Database.ExecuteSqlCommand(cmd);

            dbEntities.RawDatas.Add(new RawData { Instrument = "Bond", BusinessUnit = "BU1", profitCentre = 101, ReportingAmount = 5000 });
            dbEntities.RawDatas.Add(new RawData { Instrument = "Bond", BusinessUnit = "BU1", profitCentre = 103, ReportingAmount = 1000 });
            dbEntities.RawDatas.Add(new RawData { Instrument = "CDS", BusinessUnit = "BU1", profitCentre = 101, ReportingAmount = 5000 });
            dbEntities.RawDatas.Add(new RawData { Instrument = "CDS", BusinessUnit = "BU2", profitCentre = 101, ReportingAmount = 3000 });
            dbEntities.RawDatas.Add(new RawData { Instrument = "Equity", BusinessUnit = "BU2", profitCentre = 105, ReportingAmount = 6000 });

            dbEntities.SaveChanges();

        }

    }
}
