﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ICBC_MVC_Pivot.Models
{
    public class RawDataDto
    {
        public int TradeID { get; set; }
        public string Instrument { get; set; }
        public string BusinessUnit { get; set; }
        public Nullable<int> profitCentre { get; set; }
        public Nullable<int> ReportingAmount { get; set; }
    }
}