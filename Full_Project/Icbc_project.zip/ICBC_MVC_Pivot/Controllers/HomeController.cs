﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ICBC_MVC_Pivot.Models;
using IcbcDatabase.Model;

namespace ICBC_MVC_Pivot.Controllers
{
    public class HomeController : Controller
    {
        icbcEntities dbEntities = new icbcEntities();
        public ActionResult Index()
        {
            var lrawdata = new List<RawDataDto>();
            foreach (var rawdata in dbEntities.RawDatas)
            {
                lrawdata.Add(new RawDataDto {TradeID= rawdata.TradeID,BusinessUnit= rawdata.BusinessUnit,Instrument= rawdata.Instrument,profitCentre= rawdata.profitCentre,
                    ReportingAmount=rawdata.ReportingAmount });
            }
            
            return View(lrawdata);
        }
    }
}